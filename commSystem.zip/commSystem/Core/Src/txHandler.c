/*
 * txHandler.c
 *
 *  Created on: Apr 8, 2023
 *      Author: Neelesh
 */

#include "txHandler.h"
#include "main.h"
#include "string.h"

#define TX_FREQ 25000
#define RX_FREQ 25000
#define M 2
#define N 1
#define LOOPTEST 1
#define PHASE_SPACE (2*PI/M)
#define W 2*PI*25000

extern TIM_HandleTypeDef htim2;
void __getLineCodes(float*, float*);
void __transmit(float*, float*);

float IPhase[64 * 8];
float QPhase[64 * 8] = { 0 };
int TxlastIndx = 0;

float singleIPhase = 0;
float singleQPhase = 0;
float DACData[1250];
float txTimer = 0;
float timeStep= 1/100000;

#ifdef LOOPTEST
float RxsingleIPhase = 0;
float RxsingleQPhase = 0;
float rxTimer = 0;
void receivebit();


void __receive();
float RIPhase[64 * 8];
float RQphase[64 * 8] = { 0 };
float time = 0;
int RxlastIndx = 0;
#endif

void txStart(char *txData, int siz) {
	//Stop data collection till we store the data in IPhase and QPhase
	//It stops data collection for a period less 7*512 system Clk cycles(18us)
	//This stopping of timer may not be required since Since our data rate is 13ms, no data is lost
	HAL_TIM_Base_Stop_IT(&htim2);
	float lineCodesIPhase[M];
	float lineCodesQPhase[M] = { 0, 0 };
	__getLineCodes(lineCodesIPhase, lineCodesQPhase);
	for (int i = 0; i < siz; i++) {
		for (int j = 0; j < 8; j = j + 1) {
			IPhase[i * 8 + j] = lineCodesIPhase[(txData[i] & (0b10000000 >> j))
					>> (7 - j)];
			//QPhase[i*8 + j] = lineCodesQPhase[(txData[i] & (0b10000000 >> j))>>(7-j)];
		}
	}
	//Since Data is already stored in IPhase and QPhase, we can resume the timer to collect data.
	HAL_TIM_Base_Start_IT(&htim2);
	__transmit(IPhase,QPhase);
}


void transmit(char bit){
	singleIPhase = cosf(bit*PHASE_SPACE);
	IPhase[TxlastIndx] = singleIPhase;
	//singleQPhase = sinf(bit*PHASE_SPACE);
	for(int i =0;i<1250;i++){
		if(txTimer > 4/100000){
			txTimer = 0;
		}
		DACData[i] = singleIPhase*cosf(W*txTimer) + singleQPhase*sinf(W*txTimer);
		txTimer = txTimer + timeStep;
	}
#ifdef LOOPTEST
	receivebit();
#endif
}
void __transmit(float *inphase, float *qphase) {
	float t = 0;
	float w = 2 * PI * 27000;
	float timeStep = 1 / 100000;
	for (int i = 0; i < 64 * 8; i++) {
		for (int j = 0; j < 1250; j++) {
			DACData[j] = inphase[i] * cosf(w * t) + qphase[i] * sinf(w * t);
			t = t + timeStep;
		}
#ifdef LOOPTEST
		__receive();
#endif

#ifndef LOOPTEST
	//DAC Code
#endif
	}
}

#ifdef LOOPTEST
void receivebit(){
	RxsingleIPhase = 0;
	RxsingleQPhase = 0;
	for(int i =0;i<1250;i++){
		if(rxTimer > 4/100000){
			rxTimer = 0;
		}
		RxsingleIPhase = RxsingleIPhase + DACData[i] * cosf(W*rxTimer)/1250;
		RxsingleQPhase = RxsingleQPhase + -1*DACData[i] * sinf(W*rxTimer)/1250;
		rxTimer = rxTimer + timeStep;
	}
	RIPhase[TxlastIndx] = RxsingleIPhase;
	RQphase[TxlastIndx] = RxsingleQPhase;
	TxlastIndx++;
	if(TxlastIndx == 64*8){
		TxlastIndx = 0;
	}

}
void __receive() {
	if(RxlastIndx == 64*8){
		memset(RIPhase,0,64*8*32);
		memset(RQphase,0,64*8*32);
		RxlastIndx = 0;
		time = 0;
	}
	float w = 2 * PI * 27000;
	float timeStep = 1 / 100000;
	for (int j = 0; j < 1250; j++) {
		RIPhase[RxlastIndx] = RIPhase[RxlastIndx] + DACData[j] * cosf(w * time) / 1250;
		RQphase[RxlastIndx] = RQphase[RxlastIndx] + -1 * DACData[j] * sinf(w * time) / 1250;
		time = time + timeStep;
	}
	RxlastIndx++;
	return;
}
#endif

void __getLineCodes(float *inphase, float *qphase) {
	float phaseSpace = 2 * PI / M;
	for (int i = 0; i < M; i++) {
		inphase[i] = cosf(i * phaseSpace);
		//qphase[i] = sinf(i*phaseSpace);
	}
}
