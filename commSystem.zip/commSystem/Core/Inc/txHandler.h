/*
 * txHandler.h
 *
 *  Created on: Apr 8, 2023
 *      Author: Neelesh
 */

#ifndef INC_TXHANDLER_H_
#define INC_TXHANDLER_H_
#ifdef __cplusplus
extern "C" {
#endif


void txStart(char* , int);
void transmit(char);
#ifdef __cplusplus
}
#endif

#endif /* INC_TXHANDLER_H_ */
